import React, {use} from 'react'
import {useState} from 'react'
import ExpenseContainer from './Component/ExpenseContainer.jsx'

function App() {
  return (
    <>
    <ExpenseContainer/>
    </>
  )
}
export default App